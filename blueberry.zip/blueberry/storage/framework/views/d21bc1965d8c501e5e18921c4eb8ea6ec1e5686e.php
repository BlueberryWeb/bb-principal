<!DOCTYPE html>
<html lang="zxx">
<head>

    <!-- Metas -->
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="keywords" content="HTML5 Template Vie onepage themeforest" />
    <meta name="description" content="Vie - Onepage Multi-Purpose HTML5 Template" />
    <meta name="author" content="blueberry.mx" />

    <!-- Title  -->
    <title>Blueberry | Agencia de publicidad </title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="https://res.cloudinary.com/dra1bsh4u/image/upload/v1672696440/BlueberryMX/favicon_rvg88e.png" />

    <!-- Plugins -->
    <link rel="stylesheet" href="<?php echo e(asset('front/css/plugins.css')); ?>" />

    <!-- Core Style Css -->
    <link rel="stylesheet" href="<?php echo e(asset('front/css/style.css')); ?>" />
</head>

<body>


    


    <!-- ==================== Start Navbar ==================== -->

    <?php echo $__env->make('components.menuB', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ==================== End Navbar ==================== -->



    <!-- ==================== Start Slider ==================== -->

    <header class="slider slider-prlx fixed-slider text-center">
        <div class="swiper-container parallax-slider">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <div class="bg-img valign" data-background="https://res.cloudinary.com/dra1bsh4u/image/upload/v1672696317/BlueberryMX/index/slide-01-construyendo_mv1nkc.jpg" data-overlay-dark="6">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-8 col-md-10">
                                    <div class="caption center mt-30">
                                        <h1>Construyendo <span class="color-font">negocios</span> <br> 
                                            de <span class="color-font">valor </span> 
                                            a través de 
                                            <span class="color-font">productos</span>
                                            <span class="color-font">digitales</span>
                                            </h1>
                                        <a href="#servicios" class="butn bord curve mt-30 pLight">
                                            <span>Conocer más</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="bg-img valign" data-background="https://res.cloudinary.com/dra1bsh4u/image/upload/v1672696317/BlueberryMX/index/slide-02-estetico_xfgdxk.jpg" data-overlay-dark="6">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-7 col-md-9">
                                    <div class="caption center mt-30">
                                        <h1 class="">Funcionalmente <br> <b class="color-font">estético</b> </h1>
                                        <p>La perfecta combinación entre lo funcional y lo estético para tu E-commerce.</p>
                                        <a href="#servicios" class="butn bord curve mt-30">
                                            <span>Conocer más</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="bg-img valign" data-background="https://res.cloudinary.com/dra1bsh4u/image/upload/v1672696317/BlueberryMX/index/slide-03-intuitivo_h0yuxs.jpg" data-overlay-dark="6">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-7 col-md-9">
                                    <div class="caption center mt-30">
                                        <h1 class=""> <b class="color-font">Intuitivo,</b>  escalable y   <b class="color-font">personalizable </b></h1>
                                        <a href="#servicios" class="butn bord curve mt-30">
                                            <span>Conocer más</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- slider setting -->
            <div class="setone setwo">
                <div class="swiper-button-next swiper-nav-ctrl next-ctrl cursor-pointer">
                    <i class="fas fa-chevron-right"></i>
                </div>
                <div class="swiper-button-prev swiper-nav-ctrl prev-ctrl cursor-pointer">
                    <i class="fas fa-chevron-left"></i>
                </div>
            </div>
            <div class="swiper-pagination top botm "></div>

            <div class="social-icon">
                <a href="https://www.facebook.com/profile.php?id=100089242747257" target="_blank"><i class="fab fa-facebook-f"></i></a>
                <a href="https://www.instagram.com/blueberrymx_/" target="_blank"><i class="fab fa-instagram"></i></a>
                <a href="https://www.youtube.com/channel/UCCSwSHd-JKN08XtD0BQF1gQ" target="_blank"><i class="fab fa-youtube fz-14"></i></a>
                <a href="https://www.tiktok.com/@blueberrymx1" target="_blank"><img src="https://res.cloudinary.com/dra1bsh4u/image/upload/v1673041326/BlueberryMX/index/icono-tiktok-white_cfgwcp.png" alt="Tik Tok" class="icono-tiktok"/></a>
                <a href="https://www.linkedin.com/company/blueberrymx" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                <a href="https://vimeo.com/blueberrymx" target="_blank"><i class="fab fa-vimeo-v"></i></a>

            </div>
        </div>
    </header>

    <!-- ==================== End Slider ==================== -->



    <div class="main-content">



        <!-- ==================== Start Servicios ==================== -->

        <section class="blog section-padding sub-bg" id="servicios">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8 col-md-10">
                        <div class="sec-head  text-center">
                            <h3 class="wow fadeInUp color-font semiBold fz-70" data-wow-delay=".3s">Servicios </h3>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 mb-30">
                        <div class="item md-mb50 wow fadeInUp" data-wow-delay=".3s">
                            <div class="img">
                                <img src="https://res.cloudinary.com/dra1bsh4u/image/upload/v1673041422/BlueberryMX/index/plataforma-web-esp_delrra.jpg" alt="Platafromas web"/>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-30">
                        <div class="item md-mb50 wow fadeInUp" data-wow-delay=".5s">
                            <div class="img">
                                <img src="https://res.cloudinary.com/dra1bsh4u/image/upload/v1673041424/BlueberryMX/index/ecommerce-esp_glhm4r.jpg" alt="E-commerce"/>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-5 mb-30">
                        <div class="item md-mb50 wow fadeInUp" data-wow-delay=".3s">
                            <div class="img">
                                <img src="https://res.cloudinary.com/dra1bsh4u/image/upload/v1673041425/BlueberryMX/index/landing-pages-esp_wc9muh.jpg" alt="Landing pages"/>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-5 mb-30">
                        <div class="item md-mb50 wow fadeInUp" data-wow-delay=".5s">
                            <div class="img">
                                <img src="https://res.cloudinary.com/dra1bsh4u/image/upload/v1673041422/BlueberryMX/index/integracion-digital-esp_lln83x.jpg" alt="Integración digital de negocios"/>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- ==================== End Servicios ==================== -->



        <!-- ==================== Start Texto que cambia ==================== -->

        <section class="valign mt-100 mb-100">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 valign">
                        <div class="cont">
                            <h1 class="cd-headline clip">Desarrollamos soluciones para pequeñas y grandes marcas, construimos aunténticas identidades 
                                de negocio a través de <br/>
                                 <span class="cd-words-wrapper bold">
                                    <b class="is-visible color-font fw-600">E-commerce.</b>
                                    <b class="color-font fw-600">Desarrollo Web.</b>
                                    <b class="color-font fw-600">Plataformas autoadministrables.</b>
                                </span></h1>
                        </div>
                    </div>
                </div>

            </div>
        </section>

        <!-- ==================== End Texto que cambia ==================== -->

        <!-- ==================== Start Soluciones ==================== -->

        <section class="blog section-padding sub-bg">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8 col-md-10">
                        <div class="sec-head  text-center">
                            <h3 class="wow fadeIn color-font mb-10 semiBold fz-60" data-wow-delay=".4s">Soluciones</h3>
                            <h6 class="wow fadeIn fz-25" data-wow-delay=".5s">para cualquier modelo de negocio</h6>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 mb-30">
                        <div class="item md-mb50 wow fadeInUp" data-wow-delay=".3s">
                            <div class="img">
                                <div class="img-soluciones">
                                    <img src="https://res.cloudinary.com/dra1bsh4u/image/upload/v1672696317/BlueberryMX/index/poder-increible_lrphcp.jpg" alt="Poder increíble y diseño increíble"/>
                                    <div class="txt-soluciones">
                                        <h1 class="fz-25 semiBold">Poder increíble,</h1>
                                        <h1 class="fz-25">Diseño increíble</h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-30">
                        <div class="item md-mb50 wow fadeInUp" data-wow-delay=".5s">
                            <div class="img">
                                <div class="img-soluciones">
                                    <img src="https://res.cloudinary.com/dra1bsh4u/image/upload/v1673041422/BlueberryMX/index/experiencia_mrivuw.jpg" alt="Una experiencia de usuario increíble"/>
                                    <div class="txt-soluciones">
                                        <h1 class="fz-25 semiBold">Una experiencia de usuario</h1>
                                        <h1 class="fz-25"> increíble</h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- ==================== End Soluciones ==================== -->

        <!-- ==================== Start Tecnologías usadas ==================== -->

        <section class="clients section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 valign md-mb50">
                        <div class="sec-head mb-0">
                            <h6 class="wow fadeIn fz-25" data-wow-delay=".4s">Nuestras</h6>
                            <h3 class="wow fadeIn mb-20 color-font semiBold fz-60" data-wow-delay=".5s">Tecnologías</h3>
                            <p class="wow fadeIn fz-18" data-wow-delay=".6s">Nuestra área de experiencia es bastante extensa desde:
                                uso de frameworks, diseño, animación y edición.
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <div>
                            <div class="row bord">
                                <div class="col-md-3 col-6 brands">
                                    <div class="item wow fadeIn" data-wow-delay=".3s">
                                        <div class="img ">
                                            <img src="https://res.cloudinary.com/dra1bsh4u/image/upload/v1673041421/BlueberryMX/index/icono-laravel_utt2nl.png" alt="Laravel" class="sombra zoom"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-6 brands">
                                    <div class="item wow fadeIn" data-wow-delay=".6s">
                                        <div class="img">
                                            <img src="https://res.cloudinary.com/dra1bsh4u/image/upload/v1673041421/BlueberryMX/index/icono-react_vmfnhv.png" alt="React Js" class="sombra zoom"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-6 brands">
                                    <div class="item wow fadeIn" data-wow-delay=".8s">
                                        <div class="img">
                                            <img src="https://res.cloudinary.com/dra1bsh4u/image/upload/v1673041421/BlueberryMX/index/icono-vue_k8sx4o.png" alt="Vue Js" class="sombra zoom"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-6 brands">
                                    <div class="item wow fadeIn" data-wow-delay=".3s">
                                        <div class="img">
                                            <img src="https://res.cloudinary.com/dra1bsh4u/image/upload/v1673041421/BlueberryMX/index/icono-mysql_vh1ukz.png" alt="Mysql" class="sombra zoom"/>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3 col-6 brands sm-mb30">
                                    <div class="item wow fadeIn" data-wow-delay=".4s">
                                        <div class="img">
                                            <img src="https://res.cloudinary.com/dra1bsh4u/image/upload/v1673041421/BlueberryMX/index/icono-firebase_owjp47.png" alt="Firebase" class="sombra zoom"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-6 brands sm-mb30">
                                    <div class="item wow fadeIn" data-wow-delay=".7s">
                                        <div class="img">
                                            <img src="https://res.cloudinary.com/dra1bsh4u/image/upload/v1673041421/BlueberryMX/index/icono-after_g4l1ra.png" alt="After Efects" class="sombra zoom"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-6 brands">
                                    <div class="item wow fadeIn" data-wow-delay=".5s">
                                        <div class="img">
                                            <img src="https://res.cloudinary.com/dra1bsh4u/image/upload/v1673041421/BlueberryMX/index/icono-premier_b3nufa.png" alt="Premier" class="sombra zoom"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-6 brands">
                                    <div class="item wow fadeIn" data-wow-delay=".3s">
                                        <div class="img">
                                            <img src="https://res.cloudinary.com/dra1bsh4u/image/upload/v1673041421/BlueberryMX/index/icono-xd_ue8tfw.png" alt="XD" class="sombra zoom"/>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- ==================== End Tecnologías usadas ==================== -->


        
        <!-- ==================== Start call-to-action ==================== -->

        <section class="app-action section-padding" data-overlay-dark="0">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="box-gr">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="img">
                                        <img src="https://res.cloudinary.com/dra1bsh4u/image/upload/v1672696316/BlueberryMX/index/optimiza-cada-parte_zdehcz.png" alt="Optimiza cada parte"/>
                                    </div>
                                </div>
                                <div class="col-lg-6 valign">
                                    <div class="cont">
                                        <div class="s-head">
                                            <h2 class="semiBold">Optimiza cada parte de la experiencia del checkout para 
                                                convertir más clientes </h2>
                                            <span class="text-white fz-18">
                                                La solución para miles de negocios de todos los tamaños, desde startups pequeños hasta empresas grandes.
                                            </span>
                                        </div>
                                        <div class="butons mt-40">
                                            <a href="e-commerce.html" class="butn-bord-light rounded buton">
                                                <span>Conocer más</span>
                                            </a>
    
                                            <a href="contact.html" class="butn-bord-light rounded buton">
                                                <span>Contáctanos</span>
                                            </a>
                                        </div>
    
                                        <div class="shape-light">
                                            <img src="https://res.cloudinary.com/dra1bsh4u/image/upload/v1673041263/BlueberryMX/shape-light_fvkjwy.png" alt=""/>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- ==================== End call-to-action ==================== -->

        <!-- ==================== Start Diferenciador Blueberry ==================== -->

        <section class="app-services section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-10">
                        <div class="sec-head">
                            <h6 class="wow fadeIn  fz-25" data-wow-delay=".5s">La diferencia con Blueberry</h6>
                            <h3 class="wow fadeIn color-font semiBold fz-60" data-wow-delay=".6s">Aún más razones para<br> colaborar con nosotros.</h3>
                        </div>
                    </div>
                </div>
            </div>
            <section class="no-padding" data-scroll-index="1">
                <div class="container-fluid">
                    <div class="row justify-content-center">
                        <div class="col-lg col-md-6">
                            <div class="item mb-30 tam-cards-ch wow fadeIn" data-wow-delay=".3s">
                                <div class="item-tit mb-15">
                                    <div class="icon">
                                        <img src="https://res.cloudinary.com/dra1bsh4u/image/upload/v1672696317/BlueberryMX/index/icono-software_yruo0f.png" alt="" class="icono-software"/>
                                    </div>
                                </div>
        
                                <p class="bold fz-16"> Somos una agencia <b class="color-font">creativa de software.</b></p>
                            </div>
                        </div>
                        <div class="col-lg col-md-6">
                            <div class="item mb-30 tam-cards-ch wow fadeIn" data-wow-delay=".6s">
                                <div class="item-tit mb-15">
                                    <div class="icon">
                                        <img src="https://res.cloudinary.com/dra1bsh4u/image/upload/v1672696315/BlueberryMX/index/icono-alcance_fbe100.png" alt="" class="icono-alcance"/>
                                    </div>
                                </div>
        
                                <p class="bold fz-16"> Alcance de proyecto desarrollados de manera inteligente,
                                    logrando un proyecto <b class="color-font">innovador, estratégico y con comunicación precisa.</b> 
                                </p>
                            </div>
                        </div>
                        <div class="col-lg col-md-6">
                            <div class="item mb-30 tam-cards-ch wow fadeIn" data-wow-delay=".8s">
                                <div class="item-tit mb-15">
                                    <div class="icon">
                                        <img src="https://res.cloudinary.com/dra1bsh4u/image/upload/v1672696316/BlueberryMX/index/icono-construccion_iuevqh.png" alt="" class="icono-construccion"/>
                                    </div>
                                </div>
        
                                <p class="mb-25 bold fz-16"> Construcción del proyecto con <b class="color-font">alta tecnología.</b><br></p>
                            </div>
                        </div>
                        <div class="col-lg col-md-6">
                            <div class="item sm-mb50 tam-cards-ch wow fadeIn" data-wow-delay="1s">
                                <div class="item-tit mb-15">
                                    <div class="icon">
                                        <img src="https://res.cloudinary.com/dra1bsh4u/image/upload/v1672696315/BlueberryMX/index/icono-esencia_vzk0wt.png" alt="" class="icono-esencia"/>
                                    </div>
                                </div>
                                <p class="bold fz-16">Plasmamos la esencia, los ejes rectores y la filosofía de tu empresa 
                                    a través de diferentes <b class="color-font">recursos creativos.</b> 
                                </p>
                            </div>
                        </div>
                        <div class="col-lg col-md-6">
                            <div class="item sm-mb50 tam-cards-ch wow fadeIn" data-wow-delay="1.3s">
                                <div class="item-tit mb-15">
                                    <div class="icon">
                                        <img src="https://res.cloudinary.com/dra1bsh4u/image/upload/v1672696315/BlueberryMX/index/icono-desarrollo_ywyfbj.png" alt="" class="icono-desarrollo"/>
                                    </div>
                                </div>
        
                                <p class="mb-20 bold fz-16"> Desarrollamos sitios y herramientas con capacidad
                                    de <b class="color-font"> escalar tecnológicamente</b> a un sistema más robusto.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
                
        </section>

        <!-- ==================== End Diferenciador Blueberry ==================== -->



        <!-- ==================== Start call-to-action ==================== -->

        <?php echo $__env->make('components.callToAction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- ==================== End call-to-action ==================== -->



        <!-- ==================== Start Footer ==================== -->

        <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- ==================== End Footer ==================== -->


    </div>






   <?php echo $__env->make('components.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH /var/www/html/resources/views/welcome.blade.php ENDPATH**/ ?>