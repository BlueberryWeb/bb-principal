<!DOCTYPE html>
<html lang="en">
<head>
     <!-- Metas -->
     <meta charset="utf-8"/>
     <meta http-equiv="X-UA-Compatible" content="IE=edge" />
     <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
     <meta name="author" content="blueberry.mx" />
 
     <!-- Title  -->
     <title>Blueberry | Software company in Mexico </title>
 
     <!-- Favicon -->
     <link rel="shortcut icon" href="https://res.cloudinary.com/dej55trpk/image/upload/v1675785564/favicon_h7ecbp.png" />
 
     <!-- Plugins -->
     <link rel="stylesheet" href="<?php echo e(asset('front/css/plugins.css')); ?>" />
     <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/15.0.1/css/intlTelInput.css'/>
 
     <!-- Core Style Css -->
     <link rel="stylesheet" href="<?php echo e(asset('front/css/style.css')); ?>" />



      <!-- Messenger Plugin de chat Code -->
    <div id="fb-root"></div>

    <!-- Your Plugin de chat code -->
    <div id="fb-customer-chat" class="fb-customerchat">
    </div>

    <script>
      var chatbox = document.getElementById('fb-customer-chat');
      chatbox.setAttribute("page_id", "109035468741342");
      chatbox.setAttribute("attribution", "biz_inbox");
    </script>

    <!-- Your SDK code -->
    <script>
      window.fbAsyncInit = function() {
        FB.init({
          xfbml            : true,
          version          : 'v15.0'
        });
      };

      (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = 'https://connect.facebook.net/es_LA/sdk/xfbml.customerchat.js';
        fjs.parentNode.insertBefore(js, fjs);
      }(document, 'script', 'facebook-jssdk'));
    </script>
</head>
<body>
    
     <!-- ==================== Start Navbar ==================== -->

     <?php echo $__env->make('components.menuB', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ==================== End Navbar ==================== -->


    <header class="pages-header circle-bg valign position-re sub-bg">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8 col-md-11">
                    <div class="capt">
                        <div class="text-center">
                            <h1 class="color-font mb-10 fw-700 semiBold wow fadeInUp fz-60">Let's talk <br> about next your project.</h1>
                            <p class="regular wow text fz-18" data-splitting>Feel free to ask me any question or let's do to talk about our future collaboration.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="circle-color">
            <div class="gradient-circle"></div>
            <div class="gradient-circle two"></div>
        </div>
    </header>



    <div class="main-content">

        <!-- ==================== Start Contact ==================== -->

        <section class="contact section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="form md-mb50">
                            <h4 class="fw-700 color-font mb-50 semiBold fadeInUp fz-35">Get in touch</h4>
                            <form id="contact-form" method="POST" action="<?php echo e(route('mail')); ?>" class="needs-validation" novalidate>
                                <?php echo csrf_field(); ?>
                                <div class="controls">
                                    <div class=" mb-40">
                                        <input type="text" class="form-control" placeholder="Name" required name="name">
                                        <div class="invalid-feedback">
                                            Please enter a name
                                        </div>
                                    </div>
                                    <div class=" mb-40">
                                        <input  placeholder="Phone" disabled class="no-bordes"/>
                                        <input type="hidden" id="lada" name="lada"/>
                                    <input type="tel" name="phone" id="phone" class="form-control" data-error="Please enter a requested format - ex. 888 888-8888" value="" placeholder="" required onchange="value_input()">
                                    </div>
                                    <div class="form-group">
                                        <input class="form-control"  type="email" name="email" placeholder="Email" required>
                                        <div class="invalid-feedback">
                                            Please enter a valid email
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <textarea class="form-control" name="message" placeholder="Message" rows="4" required></textarea>
                                        <div class="invalid-feedback">
                                            Por favor enter a message
                                        </div>
                                    </div>
                                    <button type="submit" class="butn dark"><span>Send message</span></button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-lg-5 offset-lg-1">
                        <div class="cont-info">
                            <h4 class="fw-700 color-font mb-50 semiBold wow fadeInUp fz-35">Contact Info</h4>
                            <h3 class="wow" data-splitting>Let's talk</h3>
                            <div class="item mb-40">
                                <h5><a href="mailto:hello@blueberry.mx?Subject=Get%20Infomation%20Blueberry" target="_blank">hello@blueberry.mx</a></h5>
                                <a href="https://api.whatsapp.com/send?phone=523313257156" target="_blank"><h5>+52 (33) 1325 7256</h5></a>
                                <a href="tel:+523331093636" target="_blank"><h5>+52 (33) 3109 3636</h5></a>
                                
                            </div>
                            <h3 class="wow" data-splitting>Visit us</h3>
                            <div class="item">
                                <a href="https://goo.gl/maps/AhgmTgwyNhp2kmwt9" target="_blank">
                                    <h6>Av. Rubén Darío #586,
                                        <br>Guadalajara, Jal.
                                    </h6>
                                </a>
                                
                            </div>
                            <div class="social mt-50">
                                <a href="https://www.facebook.com/profile.php?id=100089242747257" class="icon" target="_blank">
                                    <i class="fab fa-facebook-f fz-20"></i>
                                </a>
                                <a href="https://www.instagram.com/blueberrymx_/" class="icon" target="_blank">
                                    <i class="fab fa-instagram fz-20"></i>
                                </a>
                                <a href="https://www.linkedin.com/company/blueberrymx" class="icon" target="_blank">
                                    <i class="fab fa-linkedin-in fz-20"></i>
                                </a>
                                <a href="https://www.youtube.com/channel/UCCSwSHd-JKN08XtD0BQF1gQ" target="_blank">
                                    <i class="fab fa-youtube fz-20"></i>
                                </a>
                                <a href="https://vimeo.com/blueberrymx" target="_blank">
                                    <i class="fab fa-vimeo-v fz-20"></i>
                                </a>
                                <a href="https://www.tiktok.com/@blueberrymx1" target="_blank">
                                    <img src="https://res.cloudinary.com/dej55trpk/image/upload/v1675785594/index/icono-tiktok-black_bofuvc.png" alt="Tik Tok" class="icono-tiktok"/>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- ==================== End Contact ==================== -->


      <!-- ==================== Start Footer ==================== -->

    <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ==================== End Footer ==================== -->

        <!-- =========== Start Button WhatsApp ================= -->
        <div class="cursor-pointer">
            <a href="https://api.whatsapp.com/send?phone=525540324042" class="btn-flotante-whats" target="_blank" rel="noopener noreferrer">
                <i class="fab fa-whatsapp"></i>
            </a>
        </div>
        
        <!-- =========== End Button WhatsApp =================== -->

    </div>

    






     <!-- ==================== End main-content ==================== -->
     <?php echo $__env->make('components.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

     <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>
     <script src='https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/15.0.1/js/intlTelInput.min.js'></script>
     <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.js'></script>
     <script>
          /* INITIALIZE PHONE INPUTS WITH THE intlTelInput FEATURE*/
 var input = document.querySelector("#phone");
 window.intlTelInput(input, {
     initialCountry: "auto",
     separateDialCode: true,
     nationalMode: false,
     geoIpLookup: callback => {
         fetch("https://ipapi.co/json")
         .then(res => res.json())
         .then(data => {
             console.log(data.country_code)
             callback(data.country_code)
         })
         .catch(() => callback("mx"));
     },
     utilsScript: "/intl-tel-input/js/utils.js?1681516311936" // just for formatting/placeholders etc
  });
 
  const value_input = () => {
     
     let lada = document.querySelector(".selected-dial-code");
     document.getElementById('lada').value = lada.innerHTML
     console.log(lada.innerHTML)
  }
 
      // Example starter JavaScript for disabling form submissions if there are invalid fields
      (function () {
      'use strict'
 
      // Fetch all the forms we want to apply custom Bootstrap validation styles to
      var forms = document.querySelectorAll('.needs-validation')
 
      // Loop over them and prevent submission
      Array.prototype.slice.call(forms)
          .forEach(function (form) {
          form.addEventListener('submit', function (event) {
              if (!form.checkValidity()) {
              event.preventDefault()
              event.stopPropagation()
              }
 
              form.classList.add('was-validated')
          }, false)
          })
      })()
      const expresiones ={
          nombre: /^[a-zA-ZÁ-ü\s]{1,49}$/,
          correo:/^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-.]+$/,
          telefono: /^\d{7,14}$/
          }
      
     </script>
</body>
</html><?php /**PATH /var/www/html/resources/views/Page/contact.blade.php ENDPATH**/ ?>