 <!-- jQuery -->
 <script src="{{ asset('front/js/jquery-3.0.0.min.js') }}"></script>
 <script src="{{ asset('front/js/jquery-migrate-3.0.0.min.js') }}"></script>

 <!-- plugins -->
 <script src="{{ asset('front/js/plugins.js') }}"></script>

 <!-- animated.headline -->
 <script src="{{ asset('front/js/animated.headline.js') }}"></script>

 

 <!-- custom scripts -->
 <script src="{{ asset('front/js/scripts.js') }}"></script>